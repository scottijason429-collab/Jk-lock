package com.jklock.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FlashlightOn
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.WbSunny
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import kotlinx.coroutines.delay

private val Ink = Color(0xFF080B13)
private val Ice = Color(0xFFEAF2FF)
private val Muted = Color(0xFFA9B6CC)
private val Cyan = Color(0xFF8BD8F5)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { JKLockScreen() }
    }
}

@Composable
fun JKLockScreen() {
    var now by remember { mutableStateOf(LocalDateTime.now()) }
    var selectedTab by remember { mutableStateOf("Today") }

    LaunchedEffect(Unit) {
        while (true) {
            now = LocalDateTime.now()
            delay(1000)
        }
    }

    val time = now.format(DateTimeFormatter.ofPattern("HH:mm"))
    val date = now.format(DateTimeFormatter.ofPattern("EEEE, d MMMM"))

    Box(
        modifier = Modifier.fillMaxSize().background(
            Brush.verticalGradient(
                listOf(Color(0xFF17243B), Color(0xFF101827), Ink, Color(0xFF05070C))
            )
        )
    ) {
        // Soft abstract glow shapes
        Box(Modifier.size(270.dp).offset(x = 180.dp, y = 100.dp)
            .blur(90.dp).background(Color(0xFF275B85), CircleShape))
        Box(Modifier.size(230.dp).offset(x = (-90).dp, y = 430.dp)
            .blur(100.dp).background(Color(0xFF34316D), CircleShape))

        Column(
            modifier = Modifier.fillMaxSize().statusBarsPadding()
                .navigationBarsPadding().padding(horizontal = 25.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(Modifier.height(22.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically) {
                Text("JK", color = Ice, fontWeight = FontWeight.Bold, letterSpacing = 3.sp)
                Text("LOCK EXPERIENCE", color = Muted, fontSize = 10.sp, letterSpacing = 2.sp)
            }

            Spacer(Modifier.height(45.dp))
            Text(date, color = Ice.copy(alpha = .92f), fontSize = 17.sp, fontWeight = FontWeight.Medium)
            Spacer(Modifier.height(4.dp))
            Text(time, color = Ice, fontSize = 82.sp, lineHeight = 88.sp,
                fontWeight = FontWeight.Light, letterSpacing = (-4).sp)
            Text("A calm moment. Your world.", color = Muted, fontSize = 12.sp,
                letterSpacing = 1.sp)

            Spacer(Modifier.height(32.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                InfoTile("WEATHER", "Kampala", "Partly cloudy", Icons.Filled.WbSunny, Modifier.weight(1f))
                InfoTile("BATTERY", "—", "Connect device data", null, Modifier.weight(1f))
            }

            Spacer(Modifier.height(18.dp))
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(26.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = .10f)),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color.White.copy(alpha = .13f))
            ) {
                Column(Modifier.padding(19.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.MusicNote, null, tint = Cyan)
                        Spacer(Modifier.width(9.dp))
                        Text("NOW PLAYING", color = Muted, fontSize = 10.sp, letterSpacing = 2.sp)
                        Spacer(Modifier.weight(1f))
                        Text("JK AUDIO", color = Cyan, fontSize = 9.sp, letterSpacing = 1.sp)
                    }
                    Spacer(Modifier.height(13.dp))
                    Text("Your soundtrack", color = Ice, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
                    Text("Connect a music app to enable playback controls", color = Muted, fontSize = 12.sp)
                    Spacer(Modifier.height(15.dp))
                    Box(Modifier.fillMaxWidth().height(3.dp).clip(CircleShape)
                        .background(Color.White.copy(alpha = .16f)))
                    Spacer(Modifier.height(10.dp))
                    Text("—:—                                      —:—", color = Muted, fontSize = 10.sp)
                }
            }

            Spacer(Modifier.weight(1f))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically) {
                Shortcut(Icons.Filled.FlashlightOn, "Torch")
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("Swipe up", color = Muted, fontSize = 11.sp)
                    Spacer(Modifier.height(8.dp))
                    Box(Modifier.width(105.dp).height(4.dp).clip(CircleShape)
                        .background(Color.White.copy(alpha = .8f)))
                }
                Shortcut(Icons.Filled.CameraAlt, "Camera")
            }
            Spacer(Modifier.height(15.dp))
            Text("JK LOCK  •  CONCEPT BUILD", color = Color.White.copy(alpha = .34f),
                fontSize = 9.sp, letterSpacing = 2.sp)
            Spacer(Modifier.height(12.dp))
        }
    }
}

@Composable
private fun InfoTile(
    heading: String, value: String, detail: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector?,
    modifier: Modifier = Modifier
) {
    Card(modifier, shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = .09f)),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color.White.copy(alpha = .10f))) {
        Column(Modifier.padding(15.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (icon != null) Icon(icon, null, tint = Cyan, modifier = Modifier.size(15.dp))
                Spacer(Modifier.width(6.dp))
                Text(heading, color = Muted, fontSize = 9.sp, letterSpacing = 1.5.sp)
            }
            Spacer(Modifier.height(10.dp))
            Text(value, color = Ice, fontSize = 20.sp, fontWeight = FontWeight.Medium)
            Text(detail, color = Muted, fontSize = 10.sp)
        }
    }
}

@Composable
private fun Shortcut(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Box(Modifier.size(52.dp).clip(CircleShape)
            .background(Color.White.copy(alpha = .13f)),
            contentAlignment = Alignment.Center) {
            Icon(icon, contentDescription = label, tint = Ice, modifier = Modifier.size(23.dp))
        }
        Spacer(Modifier.height(5.dp))
        Text(label, color = Muted, fontSize = 10.sp)
    }
}
