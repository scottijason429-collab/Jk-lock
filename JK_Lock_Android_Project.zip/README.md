# JK Lock — Android starter project

An iPhone-inspired, dark premium lock-screen companion interface for Android.

## Important
This starter project is a native Android app UI, not a replacement for Android's secure keyguard.
It does not bypass PIN, password, fingerprint, or manufacturer lock-screen security.
Weather is currently a placeholder; camera/flashlight controls are visual shortcuts until device permissions and APIs are implemented.

## Build
1. Install Android Studio on Windows.
2. Open this folder as a project.
3. Allow Gradle sync and install the Android SDK if prompted.
4. Connect your Infinix Smart 10 with USB debugging enabled, or use an emulator.
5. Press Run.

Package: `com.jklock.app`
